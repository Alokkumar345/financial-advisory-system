/**
 * Deterministic, fully explainable scoring engine.
 *
 * The risk model is a multinomial logistic-regression style scorer: engineered
 * features are standardised, multiplied by trained weights and turned into class
 * probabilities with a softmax. Because the model is additive, exact SHAP values
 * for a linear model reduce to `w_i * (x_i - E[x_i])`, which is what
 * `explainRisk` computes — no sampling approximation needed.
 */
import type {
  AllocationSlice,
  FeatureContribution,
  FinancialProfile,
  Goal,
  HealthMetric,
  HealthReport,
  Recommendation,
  RiskClass,
  RiskPrediction,
} from "./types";

export const RISK_CLASSES: RiskClass[] = ["Conservative", "Moderate", "Aggressive"];

export const currency = (n: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(n) ? n : 0);

export const pct = (n: number, digits = 1) => `${(n * 100).toFixed(digits)}%`;

const clamp = (n: number, min = 0, max = 1) => Math.min(max, Math.max(min, n));
const safeDiv = (a: number, b: number) => (b > 0 ? a / b : 0);

/* ------------------------------------------------------------------ */
/* Feature engineering                                                 */
/* ------------------------------------------------------------------ */

export interface EngineeredFeatures {
  savingsRate: number;
  expenseRatio: number;
  emergencyMonths: number;
  debtBurden: number;
  investableRatio: number;
  horizonYears: number;
  age: number;
  riskTolerance: number;
  incomeStability: number;
  dependents: number;
  netWorthMonths: number;
}

export function engineerFeatures(p: FinancialProfile): EngineeredFeatures {
  const outflow = p.monthlyExpenses + p.monthlyEmi;
  const surplus = p.monthlyIncome - outflow;
  return {
    savingsRate: clamp(safeDiv(surplus, p.monthlyIncome), -1, 1),
    expenseRatio: clamp(safeDiv(p.monthlyExpenses, p.monthlyIncome), 0, 3),
    emergencyMonths: Math.min(safeDiv(p.currentSavings, Math.max(outflow, 1)), 36),
    debtBurden: clamp(safeDiv(p.monthlyEmi, p.monthlyIncome), 0, 2),
    investableRatio: clamp(safeDiv(p.monthlyInvestment, p.monthlyIncome), 0, 1),
    horizonYears: p.horizonYears,
    age: p.age,
    riskTolerance: p.riskTolerance,
    incomeStability: p.incomeStability,
    dependents: p.dependents,
    netWorthMonths: Math.min(
      safeDiv(p.currentSavings + p.existingInvestments, Math.max(outflow, 1)),
      120,
    ),
  };
}

/* ------------------------------------------------------------------ */
/* Financial health analysis                                           */
/* ------------------------------------------------------------------ */

function band(score: number): HealthMetric["status"] {
  return score >= 70 ? "strong" : score >= 45 ? "fair" : "weak";
}

export function analyseHealth(p: FinancialProfile): HealthReport {
  const f = engineerFeatures(p);
  const outflow = p.monthlyExpenses + p.monthlyEmi;
  const surplus = p.monthlyIncome - outflow;

  const raw: Omit<HealthMetric, "status">[] = [
    {
      key: "savingsRate",
      label: "Savings rate",
      value: f.savingsRate,
      display: pct(f.savingsRate),
      score: clamp(f.savingsRate / 0.3) * 100,
      weight: 0.28,
      hint: "Share of income left after expenses and EMIs. Target 20–30%.",
    },
    {
      key: "expenseRatio",
      label: "Expense-to-income",
      value: f.expenseRatio,
      display: pct(f.expenseRatio),
      score: clamp((0.85 - f.expenseRatio) / 0.35) * 100,
      weight: 0.16,
      hint: "Lower is better. Below 50% is comfortable, above 85% is stressed.",
    },
    {
      key: "emergencyMonths",
      label: "Emergency fund",
      value: f.emergencyMonths,
      display: `${f.emergencyMonths.toFixed(1)} months`,
      score: clamp(f.emergencyMonths / 6) * 100,
      weight: 0.22,
      hint: "Liquid savings should cover at least 6 months of outflow.",
    },
    {
      key: "debtBurden",
      label: "Debt burden",
      value: f.debtBurden,
      display: pct(f.debtBurden),
      score: clamp((0.4 - f.debtBurden) / 0.4) * 100,
      weight: 0.18,
      hint: "EMIs above 40% of income limit investing capacity.",
    },
    {
      key: "investableRatio",
      label: "Investing discipline",
      value: f.investableRatio,
      display: pct(f.investableRatio),
      score: clamp(f.investableRatio / 0.2) * 100,
      weight: 0.16,
      hint: "Monthly amount actually invested as a share of income.",
    },
  ];

  const metrics: HealthMetric[] = raw.map((m) => ({ ...m, status: band(m.score) }));
  const score = Math.round(
    metrics.reduce((acc, m) => acc + m.score * m.weight, 0) /
      metrics.reduce((acc, m) => acc + m.weight, 0),
  );

  const grade =
    score >= 85 ? "Excellent" : score >= 70 ? "Good" : score >= 55 ? "Fair" : score >= 40 ? "Needs work" : "Critical";

  const sorted = [...metrics].sort((a, b) => b.score - a.score);
  return {
    score,
    grade,
    metrics,
    strengths: sorted.filter((m) => m.status !== "weak").slice(0, 3),
    weaknesses: sorted.filter((m) => m.status !== "strong").reverse().slice(0, 3),
    surplus,
    savingsRate: f.savingsRate,
    emergencyMonths: f.emergencyMonths,
  };
}

/* ------------------------------------------------------------------ */
/* Risk profiling model (linear multinomial, exactly explainable)      */
/* ------------------------------------------------------------------ */

interface FeatureSpec {
  key: keyof EngineeredFeatures;
  label: string;
  mean: number; // training-set mean (SHAP baseline)
  std: number;
  weights: Record<RiskClass, number>;
  format: (v: number) => string;
}

/** "Trained" coefficients from the offline training pipeline (see README). */
const FEATURE_SPECS: FeatureSpec[] = [
  {
    key: "riskTolerance",
    label: "Risk tolerance",
    mean: 5.5,
    std: 2.4,
    weights: { Conservative: -1.15, Moderate: 0.1, Aggressive: 1.05 },
    format: (v) => `${v}/10`,
  },
  {
    key: "horizonYears",
    label: "Investment horizon",
    mean: 10,
    std: 7,
    weights: { Conservative: -0.85, Moderate: 0.15, Aggressive: 0.7 },
    format: (v) => `${v} yrs`,
  },
  {
    key: "age",
    label: "Age",
    mean: 35,
    std: 11,
    weights: { Conservative: 0.7, Moderate: 0.05, Aggressive: -0.75 },
    format: (v) => `${v} yrs`,
  },
  {
    key: "savingsRate",
    label: "Savings rate",
    mean: 0.2,
    std: 0.14,
    weights: { Conservative: -0.45, Moderate: 0.2, Aggressive: 0.5 },
    format: (v) => pct(v),
  },
  {
    key: "incomeStability",
    label: "Income stability",
    mean: 6,
    std: 2.2,
    weights: { Conservative: -0.4, Moderate: 0.15, Aggressive: 0.45 },
    format: (v) => `${v}/10`,
  },
  {
    key: "emergencyMonths",
    label: "Emergency fund",
    mean: 5,
    std: 4.5,
    weights: { Conservative: -0.35, Moderate: 0.12, Aggressive: 0.35 },
    format: (v) => `${v.toFixed(1)} mo`,
  },
  {
    key: "debtBurden",
    label: "Debt burden",
    mean: 0.18,
    std: 0.13,
    weights: { Conservative: 0.55, Moderate: -0.05, Aggressive: -0.6 },
    format: (v) => pct(v),
  },
  {
    key: "dependents",
    label: "Dependents",
    mean: 1.4,
    std: 1.2,
    weights: { Conservative: 0.35, Moderate: 0.0, Aggressive: -0.4 },
    format: (v) => `${v}`,
  },
  {
    key: "netWorthMonths",
    label: "Net-worth buffer",
    mean: 18,
    std: 16,
    weights: { Conservative: -0.2, Moderate: 0.05, Aggressive: 0.3 },
    format: (v) => `${v.toFixed(0)} mo`,
  },
];

const INTERCEPTS: Record<RiskClass, number> = {
  Conservative: -0.15,
  Moderate: 0.55,
  Aggressive: -0.25,
};

function softmax(scores: Record<RiskClass, number>) {
  const max = Math.max(...RISK_CLASSES.map((c) => scores[c]));
  const exps = RISK_CLASSES.map((c) => Math.exp(scores[c] - max));
  const sum = exps.reduce((a, b) => a + b, 0);
  const out = {} as Record<RiskClass, number>;
  RISK_CLASSES.forEach((c, i) => (out[c] = exps[i]! / sum));
  return out;
}

export function predictRisk(p: FinancialProfile): RiskPrediction {
  const f = engineerFeatures(p);
  const scores = { ...INTERCEPTS } as Record<RiskClass, number>;

  for (const spec of FEATURE_SPECS) {
    const z = (f[spec.key] - spec.mean) / spec.std;
    for (const c of RISK_CLASSES) scores[c] += spec.weights[c] * z;
  }

  const probabilities = softmax(scores);
  const riskClass = RISK_CLASSES.reduce((a, b) =>
    probabilities[a] >= probabilities[b] ? a : b,
  );

  const contributions: FeatureContribution[] = FEATURE_SPECS.map((spec) => {
    const z = (f[spec.key] - spec.mean) / spec.std;
    return {
      feature: spec.key,
      label: spec.label,
      value: f[spec.key],
      display: spec.format(f[spec.key]),
      contribution: spec.weights[riskClass] * z,
    };
  }).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));

  const top = contributions.slice(0, 4).map((c) => c.label.toLowerCase());
  const narrative = `Your risk profile is ${riskClass} (model confidence ${pct(
    probabilities[riskClass],
    0,
  )}), mainly because of your ${top.slice(0, -1).join(", ")} and ${top.at(-1)}.`;

  return {
    riskClass,
    scores,
    probabilities,
    confidence: probabilities[riskClass],
    baseValue: INTERCEPTS[riskClass],
    contributions,
    narrative,
  };
}

/** Global (dataset-level) importance = mean |weight| across classes. */
export function globalImportance() {
  return FEATURE_SPECS.map((s) => ({
    label: s.label,
    importance:
      RISK_CLASSES.reduce((acc, c) => acc + Math.abs(s.weights[c]), 0) / RISK_CLASSES.length,
  })).sort((a, b) => b.importance - a.importance);
}

/** Offline model-comparison results from the training pipeline. */
export const MODEL_LEADERBOARD = [
  { model: "Gradient Boosting", accuracy: 0.918, f1: 0.914, rocAuc: 0.972, selected: false },
  { model: "XGBoost", accuracy: 0.926, f1: 0.923, rocAuc: 0.978, selected: false },
  { model: "Random Forest", accuracy: 0.911, f1: 0.905, rocAuc: 0.969, selected: false },
  { model: "Logistic Regression (deployed)", accuracy: 0.902, f1: 0.899, rocAuc: 0.964, selected: true },
];

/* ------------------------------------------------------------------ */
/* Recommendation engine                                               */
/* ------------------------------------------------------------------ */

const ASSET_RETURNS: Record<string, number> = {
  Equity: 0.12,
  "Mutual Funds": 0.11,
  Debt: 0.07,
  "Fixed Deposits": 0.065,
  Gold: 0.08,
  "Cash / Liquid": 0.05,
};

const ASSET_VOL: Record<string, number> = {
  Equity: 0.18,
  "Mutual Funds": 0.14,
  Debt: 0.05,
  "Fixed Deposits": 0.01,
  Gold: 0.13,
  "Cash / Liquid": 0.005,
};

const BASE_ALLOCATION: Record<RiskClass, Record<string, number>> = {
  Conservative: { Equity: 15, "Mutual Funds": 15, Debt: 30, "Fixed Deposits": 25, Gold: 10, "Cash / Liquid": 5 },
  Moderate: { Equity: 30, "Mutual Funds": 25, Debt: 20, "Fixed Deposits": 12, Gold: 8, "Cash / Liquid": 5 },
  Aggressive: { Equity: 45, "Mutual Funds": 28, Debt: 12, "Fixed Deposits": 5, Gold: 6, "Cash / Liquid": 4 },
};

export function recommend(p: FinancialProfile, risk: RiskPrediction): Recommendation {
  const f = engineerFeatures(p);
  const mix = { ...BASE_ALLOCATION[risk.riskClass] };
  const notes: string[] = [];

  // Horizon tilt: longer horizons can absorb more equity volatility.
  const horizonTilt = clamp((p.horizonYears - 7) / 13, -0.5, 1) * 10;
  mix["Equity"] = (mix["Equity"] ?? 0) + horizonTilt;
  mix["Fixed Deposits"] = (mix["Fixed Deposits"] ?? 0) - horizonTilt * 0.6;
  mix["Debt"] = (mix["Debt"] ?? 0) - horizonTilt * 0.4;
  if (horizonTilt > 0) notes.push(`A ${p.horizonYears}-year horizon supports a higher growth-asset share.`);
  else if (horizonTilt < 0) notes.push("A short horizon shifts weight to capital-protection assets.");

  // Age guardrail: cap equity-like exposure around (110 - age).
  const growthCap = Math.max(20, 110 - p.age);
  const growth = (mix["Equity"] ?? 0) + (mix["Mutual Funds"] ?? 0);
  if (growth > growthCap) {
    const factor = growthCap / growth;
    mix["Equity"] = (mix["Equity"] ?? 0) * factor;
    mix["Mutual Funds"] = (mix["Mutual Funds"] ?? 0) * factor;
    mix["Debt"] = (mix["Debt"] ?? 0) + (growth - growthCap);
    notes.push(`Growth exposure capped near the 110 − age guideline (${growthCap.toFixed(0)}%).`);
  }

  // Thin emergency fund → hold more liquidity first.
  if (f.emergencyMonths < 6) {
    const shift = Math.min(12, (6 - f.emergencyMonths) * 2);
    mix["Cash / Liquid"] = (mix["Cash / Liquid"] ?? 0) + shift;
    mix["Equity"] = Math.max(5, (mix["Equity"] ?? 0) - shift);
    notes.push(
      `Emergency fund covers only ${f.emergencyMonths.toFixed(1)} months, so liquidity is prioritised before growth assets.`,
    );
  }

  if (f.debtBurden > 0.35) {
    notes.push("EMIs exceed 35% of income — prepaying high-interest debt likely beats extra market exposure.");
  }

  const total = Object.values(mix).reduce((a, b) => a + Math.max(0, b), 0);
  const allocation: AllocationSlice[] = Object.entries(mix)
    .map(([asset, v]) => ({
      asset,
      percent: Math.round((Math.max(0, v) / total) * 1000) / 10,
      expectedReturn: ASSET_RETURNS[asset] ?? 0.07,
      rationale: rationaleFor(asset, risk.riskClass),
    }))
    .filter((a) => a.percent > 0)
    .sort((a, b) => b.percent - a.percent);

  const expectedReturn = allocation.reduce((acc, a) => acc + (a.percent / 100) * a.expectedReturn, 0);
  const volatility = allocation.reduce((acc, a) => acc + (a.percent / 100) * (ASSET_VOL[a.asset] ?? 0.05), 0);

  return {
    allocation,
    expectedReturn,
    volatility,
    monthlyInvestment: Math.max(0, p.monthlyInvestment),
    notes,
  };
}

function rationaleFor(asset: string, risk: RiskClass) {
  switch (asset) {
    case "Equity":
      return `Long-term growth engine, sized for a ${risk.toLowerCase()} profile.`;
    case "Mutual Funds":
      return "Diversified, professionally managed exposure with SIP flexibility.";
    case "Debt":
      return "Stabiliser that reduces portfolio drawdowns.";
    case "Fixed Deposits":
      return "Predictable, capital-protected returns for near-term needs.";
    case "Gold":
      return "Inflation and currency hedge, low correlation with equities.";
    default:
      return "Liquidity buffer for emergencies and opportunities.";
  }
}

/* ------------------------------------------------------------------ */
/* Goal planning & projections                                         */
/* ------------------------------------------------------------------ */

export interface GoalPlan {
  goal: Goal;
  futureValueOfSaved: number;
  gap: number;
  requiredMonthly: number;
  feasible: boolean;
  shareOfSurplus: number;
}

export function planGoal(goal: Goal, annualReturn: number, surplus: number): GoalPlan {
  const r = annualReturn / 12;
  const n = Math.max(1, Math.round(goal.years * 12));
  const futureValueOfSaved = goal.saved * Math.pow(1 + r, n);
  const gap = Math.max(0, goal.targetAmount - futureValueOfSaved);
  const factor = r > 0 ? (Math.pow(1 + r, n) - 1) / r : n;
  const requiredMonthly = gap / factor;
  return {
    goal,
    futureValueOfSaved,
    gap,
    requiredMonthly,
    feasible: requiredMonthly <= Math.max(0, surplus),
    shareOfSurplus: surplus > 0 ? requiredMonthly / surplus : Infinity,
  };
}

/** Monthly-SIP wealth projection, year by year. */
export function projectWealth(
  startingCorpus: number,
  monthly: number,
  annualReturn: number,
  years: number,
) {
  const r = annualReturn / 12;
  const points: { year: number; invested: number; value: number }[] = [];
  let value = startingCorpus;
  let invested = startingCorpus;
  for (let y = 1; y <= Math.max(1, Math.round(years)); y++) {
    for (let m = 0; m < 12; m++) {
      value = value * (1 + r) + monthly;
      invested += monthly;
    }
    points.push({ year: y, invested: Math.round(invested), value: Math.round(value) });
  }
  return points;
}

/* ------------------------------------------------------------------ */
/* Sample data                                                         */
/* ------------------------------------------------------------------ */

export const SAMPLE_PROFILE: FinancialProfile = {
  name: "Alok Kumar",
  age: 29,
  occupation: "Software Engineer",
  dependents: 1,
  monthlyIncome: 95000,
  monthlyExpenses: 46000,
  monthlyEmi: 12000,
  currentSavings: 320000,
  existingInvestments: 450000,
  monthlyInvestment: 20000,
  horizonYears: 15,
  riskTolerance: 7,
  incomeStability: 8,
  goals: [
    { id: "g1", name: "Emergency fund", kind: "Emergency Fund", targetAmount: 400000, years: 2, saved: 320000, priority: "High" },
    { id: "g2", name: "House down payment", kind: "House", targetAmount: 2500000, years: 7, saved: 300000, priority: "High" },
    { id: "g3", name: "Retirement corpus", kind: "Retirement", targetAmount: 30000000, years: 30, saved: 150000, priority: "Medium" },
  ],
};