/** Domain types for the financial advisory engine. */

export type RiskClass = "Conservative" | "Moderate" | "Aggressive";

export type GoalKind =
  | "House"
  | "Higher Education"
  | "Emergency Fund"
  | "Retirement"
  | "Car"
  | "Travel"
  | "Other";

export interface Goal {
  id: string;
  name: string;
  kind: GoalKind;
  targetAmount: number;
  years: number;
  /** Amount already saved towards this goal. */
  saved: number;
  priority: "High" | "Medium" | "Low";
}

export interface FinancialProfile {
  name: string;
  age: number;
  occupation: string;
  dependents: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlyEmi: number;
  currentSavings: number;
  existingInvestments: number;
  monthlyInvestment: number;
  horizonYears: number;
  /** Self-declared risk tolerance, 1 (very low) – 10 (very high). */
  riskTolerance: number;
  /** Perceived income stability, 1 (unstable) – 10 (very stable). */
  incomeStability: number;
  goals: Goal[];
}

export interface HealthMetric {
  key: string;
  label: string;
  value: number;
  display: string;
  score: number; // 0-100 sub-score
  weight: number;
  status: "strong" | "fair" | "weak";
  hint: string;
}

export interface HealthReport {
  score: number;
  grade: string;
  metrics: HealthMetric[];
  strengths: HealthMetric[];
  weaknesses: HealthMetric[];
  surplus: number;
  savingsRate: number;
  emergencyMonths: number;
}

export interface FeatureContribution {
  feature: string;
  label: string;
  value: number;
  display: string;
  /** SHAP-style signed contribution to the predicted class score. */
  contribution: number;
}

export interface RiskPrediction {
  riskClass: RiskClass;
  scores: Record<RiskClass, number>;
  probabilities: Record<RiskClass, number>;
  confidence: number;
  baseValue: number;
  contributions: FeatureContribution[];
  narrative: string;
}

export interface AllocationSlice {
  asset: string;
  percent: number;
  expectedReturn: number;
  rationale: string;
}

export interface Recommendation {
  allocation: AllocationSlice[];
  expectedReturn: number;
  volatility: number;
  monthlyInvestment: number;
  notes: string[];
}