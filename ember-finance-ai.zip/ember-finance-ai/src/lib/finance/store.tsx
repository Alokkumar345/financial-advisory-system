import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { SAMPLE_PROFILE, analyseHealth, predictRisk, recommend } from "./engine";
import type { FinancialProfile } from "./types";

const PROFILE_KEY = "fps.profile.v1";
const SESSION_KEY = "fps.session.v1";

export interface Session {
  name: string;
  email: string;
}

interface Ctx {
  hydrated: boolean;
  profile: FinancialProfile;
  updateProfile: (patch: Partial<FinancialProfile>) => void;
  resetProfile: () => void;
  session: Session | null;
  signIn: (s: Session) => void;
  signOut: () => void;
}

const ProfileContext = createContext<Ctx | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<FinancialProfile>(SAMPLE_PROFILE);
  const [session, setSession] = useState<Session | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(PROFILE_KEY);
      if (raw) setProfile({ ...SAMPLE_PROFILE, ...(JSON.parse(raw) as FinancialProfile) });
      const s = localStorage.getItem(SESSION_KEY);
      if (s) setSession(JSON.parse(s) as Session);
    } catch {
      /* corrupt storage — fall back to the sample profile */
    }
    setHydrated(true);
  }, []);

  const updateProfile = useCallback((patch: Partial<FinancialProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...patch };
      try {
        localStorage.setItem(PROFILE_KEY, JSON.stringify(next));
      } catch {
        /* storage unavailable */
      }
      return next;
    });
  }, []);

  const resetProfile = useCallback(() => {
    setProfile(SAMPLE_PROFILE);
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(SAMPLE_PROFILE));
    } catch {
      /* ignore */
    }
  }, []);

  const signIn = useCallback((s: Session) => {
    setSession(s);
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
  }, []);

  const signOut = useCallback(() => {
    setSession(null);
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo(
    () => ({ hydrated, profile, updateProfile, resetProfile, session, signIn, signOut }),
    [hydrated, profile, updateProfile, resetProfile, session, signIn, signOut],
  );

  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error("useProfile must be used inside ProfileProvider");
  return ctx;
}

/** Derived analytics for the active profile. */
export function useAnalysis() {
  const { profile } = useProfile();
  return useMemo(() => {
    const health = analyseHealth(profile);
    const risk = predictRisk(profile);
    const recommendation = recommend(profile, risk);
    return { health, risk, recommendation };
  }, [profile]);
}