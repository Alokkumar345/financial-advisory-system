import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const ChatInput = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().min(1).max(4000),
      }),
    )
    .min(1)
    .max(30),
  context: z.string().max(4000),
});

/**
 * AI financial assistant. Runs entirely server-side so the gateway key is
 * never exposed. Returns a friendly error string instead of throwing so the
 * UI can surface rate-limit / credit problems cleanly.
 */
export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ChatInput.parse(input))
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { ok: false as const, error: "AI is not configured for this deployment." };

    const system = [
      "You are FinAdvisor XAI's educational financial assistant.",
      "Explain financial metrics, the health score, ML risk predictions, SHAP-style explanations and recommended allocations in simple language.",
      "Never promise or guarantee returns. Never claim certainty. Use hedged language.",
      "Always remind the user that this is educational decision support and that a licensed/SEBI-registered financial adviser should be consulted for regulated advice when they ask for actionable decisions.",
      "Keep answers under 200 words, use short paragraphs or bullets, and reference the user's actual numbers below when relevant.",
      "",
      "User's current financial context:",
      data.context,
    ].join("\n");

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Lovable-API-Key": key },
        body: JSON.stringify({
          model: "openai/gpt-5.6-sol",
          input: [
            { role: "system", content: system },
            ...data.messages.map((m) => ({ role: m.role, content: m.content })),
          ],
        }),
      });

      if (res.status === 429) return { ok: false as const, error: "Too many requests right now — please retry in a moment." };
      if (res.status === 402) return { ok: false as const, error: "AI credits are exhausted. Add credits to continue using the assistant." };
      if (!res.ok) return { ok: false as const, error: `Assistant unavailable (status ${res.status}).` };

      const json = (await res.json()) as {
        output_text?: string;
        output?: { content?: { type?: string; text?: string }[] }[];
      };
      const text =
        json.output_text ??
        json.output
          ?.flatMap((o) => o.content ?? [])
          .filter((c) => c.type === "output_text")
          .map((c) => c.text ?? "")
          .join("\n")
          .trim();

      if (!text) return { ok: false as const, error: "The assistant returned an empty response." };
      return { ok: true as const, text };
    } catch {
      return { ok: false as const, error: "Could not reach the AI service. Check your connection and retry." };
    }
  });
