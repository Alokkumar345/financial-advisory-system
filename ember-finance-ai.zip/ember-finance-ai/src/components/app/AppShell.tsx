import { Link } from "@tanstack/react-router";
import {
  Activity,
  BarChart3,
  Bot,
  FileText,
  Gauge,
  LayoutDashboard,
  PieChart,
  Sparkles,
  SlidersHorizontal,
  Target,
  UserCog,
  LogOut,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { useProfile } from "@/lib/finance/store";
import { Button } from "@/components/ui/button";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/profile", label: "Financial Profile", icon: UserCog },
  { to: "/risk", label: "Risk Assessment", icon: Gauge },
  { to: "/recommendations", label: "Investment Plan", icon: PieChart },
  { to: "/goals", label: "Goal Planner", icon: Target },
  { to: "/simulator", label: "What-If Simulator", icon: SlidersHorizontal },
  { to: "/explainability", label: "Explainable AI", icon: BarChart3 },
  { to: "/assistant", label: "AI Assistant", icon: Bot },
  { to: "/reports", label: "Reports & Export", icon: FileText },
] as const;

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { session, signOut, profile } = useProfile();
  const [open, setOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-background">
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 shrink-0 bg-sidebar text-sidebar-foreground transition-transform lg:static lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-5">
          <Activity className="size-5 text-sidebar-primary" />
          <span className="font-display text-sm font-semibold tracking-tight">FinAdvisor XAI</span>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              onClick={() => setOpen(false)}
              activeOptions={{ exact: to === "/" }}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              activeProps={{
                className:
                  "bg-sidebar-accent text-sidebar-accent-foreground font-medium ring-1 ring-sidebar-border",
              }}
            >
              <Icon className="size-4" />
              {label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto px-4 pb-5 pt-2 text-[11px] leading-relaxed text-sidebar-foreground/60">
          Educational decision-support tool. Not investment advice.
        </div>
      </aside>

      {open && (
        <button
          aria-label="Close navigation"
          className="fixed inset-0 z-30 bg-foreground/40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-3 border-b border-border bg-card/85 px-4 backdrop-blur md:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setOpen((v) => !v)}>
              Menu
            </Button>
            <div className="min-w-0">
              <h1 className="truncate text-base font-semibold md:text-lg">{title}</h1>
              {subtitle && <p className="truncate text-xs text-muted-foreground">{subtitle}</p>}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <p className="text-sm font-medium">{session?.name ?? profile.name}</p>
              <p className="text-xs text-muted-foreground">{session?.email ?? "demo session"}</p>
            </div>
            {session ? (
              <Button variant="outline" size="sm" onClick={signOut}>
                <LogOut className="size-4" /> Sign out
              </Button>
            ) : (
              <Button asChild size="sm">
                <Link to="/auth">
                  <Sparkles className="size-4" /> Sign in
                </Link>
              </Button>
            )}
          </div>
        </header>
        <main className="flex-1 p-4 md:p-8">{children}</main>
        <footer className="border-t border-border px-4 py-4 text-xs text-muted-foreground md:px-8">
          Disclaimer: FinAdvisor XAI is an educational decision-support project. Outputs are model
          estimates, not guaranteed returns or regulated financial advice. Consult a SEBI-registered
          adviser before investing.
        </footer>
      </div>
    </div>
  );
}