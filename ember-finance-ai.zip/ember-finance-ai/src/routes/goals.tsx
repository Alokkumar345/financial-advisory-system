import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAnalysis, useProfile } from "@/lib/finance/store";
import { currency, planGoal } from "@/lib/finance/engine";
import type { Goal, GoalKind } from "@/lib/finance/types";

export const Route = createFileRoute("/goals")({
  head: () => ({
    meta: [
      { title: "Financial Goal Planner — FinAdvisor XAI" },
      { name: "description", content: "Plan house, education, retirement and emergency goals with required monthly SIPs." },
      { property: "og:title", content: "Financial Goal Planner — FinAdvisor XAI" },
      { property: "og:description", content: "See the monthly investment each goal needs and whether it fits your surplus." },
    ],
  }),
  component: GoalsPage,
});

const KINDS: GoalKind[] = ["House", "Higher Education", "Emergency Fund", "Retirement", "Car", "Travel", "Other"];

function GoalsPage() {
  const { profile, updateProfile } = useProfile();
  const { health, recommendation } = useAnalysis();
  const [draft, setDraft] = useState({ name: "", kind: "House" as GoalKind, targetAmount: 1000000, years: 5, saved: 0 });

  const plans = profile.goals.map((g) => planGoal(g, recommendation.expectedReturn, health.surplus));
  const totalRequired = plans.reduce((a, p) => a + p.requiredMonthly, 0);

  const addGoal = (): void => {
    if (draft.name.trim().length < 2) {
      toast.error("Give the goal a name.");
      return;
    }
    if (draft.targetAmount <= 0 || draft.years <= 0 || draft.saved < 0) {
      toast.error("Target, timeline and saved amount must be valid positive values.");
      return;
    }
    const goal: Goal = { id: crypto.randomUUID(), priority: "Medium", ...draft };
    updateProfile({ goals: [...profile.goals, goal] });
    setDraft({ name: "", kind: "House", targetAmount: 1000000, years: 5, saved: 0 });
    toast.success("Goal added.");
  };

  const removeGoal = (id: string) => updateProfile({ goals: profile.goals.filter((g) => g.id !== id) });

  const chartData = plans.map((p) => ({
    name: p.goal.name,
    required: Math.round(p.requiredMonthly),
    capacity: Math.round(Math.max(0, health.surplus)),
  }));

  return (
    <AppShell title="Financial Goal Planner" subtitle="Required monthly investment per goal versus your capacity">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Your goals</CardTitle>
            <CardDescription>
              Total required {currency(totalRequired)}/month · available surplus {currency(health.surplus)}/month
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {plans.length === 0 && <p className="text-sm text-muted-foreground">No goals yet — add one on the right.</p>}
            {plans.map((p) => (
              <div key={p.goal.id} className="rounded-xl border border-border p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-medium">{p.goal.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {p.goal.kind} · {currency(p.goal.targetAmount)} in {p.goal.years} years
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={p.feasible ? "default" : "destructive"}>
                      {p.feasible ? "On track" : "Stretch"}
                    </Badge>
                    <Button variant="ghost" size="icon" onClick={() => removeGoal(p.goal.id)} aria-label={`Remove ${p.goal.name}`}>
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  <Stat label="Required / month" value={currency(p.requiredMonthly)} />
                  <Stat label="Projected value of savings" value={currency(p.futureValueOfSaved)} />
                  <Stat label="Shortfall to fund" value={currency(p.gap)} />
                </div>
                <div className="mt-3">
                  <Progress value={Math.min(100, (p.goal.saved / Math.max(1, p.goal.targetAmount)) * 100)} />
                  <p className="mt-1 text-xs text-muted-foreground">
                    {((p.goal.saved / Math.max(1, p.goal.targetAmount)) * 100).toFixed(1)}% funded today ·
                    {" "}
                    {Number.isFinite(p.shareOfSurplus) ? `${(p.shareOfSurplus * 100).toFixed(0)}% of your monthly surplus` : "no surplus available"}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="card-elevated h-fit">
          <CardHeader>
            <CardTitle>Add a goal</CardTitle>
            <CardDescription>Amounts in INR</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="goal-name">Goal name</Label>
              <Input id="goal-name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Child's education" />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={draft.kind} onValueChange={(v) => setDraft({ ...draft, kind: v as GoalKind })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {KINDS.map((k) => <SelectItem key={k} value={k}>{k}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="goal-target">Target amount</Label>
              <Input id="goal-target" type="number" min={0} value={draft.targetAmount} onChange={(e) => setDraft({ ...draft, targetAmount: Math.max(0, Number(e.target.value)) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="goal-years">Years to goal</Label>
              <Input id="goal-years" type="number" min={1} value={draft.years} onChange={(e) => setDraft({ ...draft, years: Math.max(0, Number(e.target.value)) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="goal-saved">Already saved</Label>
              <Input id="goal-saved" type="number" min={0} value={draft.saved} onChange={(e) => setDraft({ ...draft, saved: Math.max(0, Number(e.target.value)) })} />
            </div>
            <Button className="w-full" onClick={addGoal}>Add goal</Button>
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-3">
          <CardHeader>
            <CardTitle>Required SIP vs monthly capacity</CardTitle>
            <CardDescription>Assumes {(recommendation.expectedReturn * 100).toFixed(1)}% expected annual return from your allocation</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => currency(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="required" name="Required / month" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="capacity" name="Monthly surplus" fill="var(--color-chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-secondary p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}
