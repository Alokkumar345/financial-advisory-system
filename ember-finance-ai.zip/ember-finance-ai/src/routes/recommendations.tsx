import { createFileRoute } from "@tanstack/react-router";
import {
  Area,
  AreaChart,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/app/AppShell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAnalysis, useProfile } from "@/lib/finance/store";
import { currency, pct, projectWealth } from "@/lib/finance/engine";
import { Info } from "lucide-react";

export const Route = createFileRoute("/recommendations")({
  head: () => ({
    meta: [
      { title: "Investment Recommendation — FinAdvisor XAI" },
      { name: "description", content: "Personalised asset allocation across equity, debt, mutual funds, FDs and gold." },
      { property: "og:title", content: "Investment Recommendation — FinAdvisor XAI" },
      { property: "og:description", content: "An explainable allocation built from your risk profile, horizon and goals." },
    ],
  }),
  component: RecommendationPage,
});

const COLORS = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
  "var(--color-muted-foreground)",
];

function RecommendationPage() {
  const { profile } = useProfile();
  const { risk, recommendation } = useAnalysis();

  const projection = projectWealth(
    profile.existingInvestments,
    recommendation.monthlyInvestment,
    recommendation.expectedReturn,
    profile.horizonYears,
  );
  const final = projection.at(-1);

  return (
    <AppShell title="Personalised Investment Recommendation" subtitle={`Allocation tuned for a ${risk.riskClass} profile`}>
      <Alert className="mb-6">
        <Info className="size-4" />
        <AlertTitle>Educational decision support</AlertTitle>
        <AlertDescription>
          This allocation is a model-generated illustration, not guaranteed returns or regulated advice.
          Expected returns are long-run assumptions and actual outcomes will vary.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-1">
          <CardHeader>
            <CardTitle>Recommended allocation</CardTitle>
            <CardDescription>Monthly investment {currency(recommendation.monthlyInvestment)}</CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={recommendation.allocation}
                  dataKey="percent"
                  nameKey="asset"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {recommendation.allocation.map((a, i) => (
                    <Cell key={a.asset} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Tooltip formatter={(v: number) => `${v}%`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Asset-class breakdown</CardTitle>
            <CardDescription>
              Blended expected return {pct(recommendation.expectedReturn)} · estimated volatility {pct(recommendation.volatility)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Asset class</TableHead>
                  <TableHead className="text-right">Allocation</TableHead>
                  <TableHead className="text-right">Monthly</TableHead>
                  <TableHead>Why</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recommendation.allocation.map((a) => (
                  <TableRow key={a.asset}>
                    <TableCell className="font-medium">{a.asset}</TableCell>
                    <TableCell className="text-right">{a.percent}%</TableCell>
                    <TableCell className="text-right">
                      {currency((a.percent / 100) * recommendation.monthlyInvestment)}
                    </TableCell>
                    <TableCell className="max-w-xs text-xs text-muted-foreground">{a.rationale}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Projected corpus</CardTitle>
            <CardDescription>
              SIP projection over {profile.horizonYears} years at {pct(recommendation.expectedReturn)} expected annual return
            </CardDescription>
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={projection}>
                <defs>
                  <linearGradient id="corpus" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-chart-2)" stopOpacity={0.7} />
                    <stop offset="100%" stopColor="var(--color-chart-2)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="year" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                  tickFormatter={(v: number) => `${(v / 100000).toFixed(0)}L`}
                />
                <Tooltip formatter={(v: number) => currency(v)} />
                <Area type="monotone" dataKey="invested" stroke="var(--color-chart-1)" fill="none" name="Invested" />
                <Area type="monotone" dataKey="value" stroke="var(--color-chart-2)" fill="url(#corpus)" name="Projected value" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Plan notes</CardTitle>
            <CardDescription>Rules that shaped this allocation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="rounded-lg bg-secondary p-3">
              <p className="text-xs text-muted-foreground">Projected corpus in {profile.horizonYears} years</p>
              <p className="font-display text-xl font-semibold">{currency(final?.value ?? 0)}</p>
              <p className="text-xs text-muted-foreground">Invested: {currency(final?.invested ?? 0)}</p>
            </div>
            {recommendation.notes.length === 0 && <p className="text-muted-foreground">Baseline allocation applied with no overrides.</p>}
            {recommendation.notes.map((n) => (
              <p key={n} className="flex gap-2">
                <Badge variant="secondary" className="h-fit">Rule</Badge>
                <span className="text-muted-foreground">{n}</span>
              </p>
            ))}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
