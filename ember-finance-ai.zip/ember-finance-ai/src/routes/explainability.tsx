import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, Cell, PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell } from "@/components/app/AppShell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Brain } from "lucide-react";
import { useAnalysis } from "@/lib/finance/store";
import { MODEL_LEADERBOARD, globalImportance, pct } from "@/lib/finance/engine";

export const Route = createFileRoute("/explainability")({
  head: () => ({
    meta: [
      { title: "Explainable AI Dashboard — FinAdvisor XAI" },
      { name: "description", content: "SHAP-style local and global feature importance behind every risk prediction." },
      { property: "og:title", content: "Explainable AI Dashboard — FinAdvisor XAI" },
      { property: "og:description", content: "Understand exactly which financial factors drove the model's output." },
    ],
  }),
  component: XaiPage,
});

const PIPELINE = [
  ["Data collection", "Profile inputs + synthetic training cohort"],
  ["Data cleaning", "Range checks, negative-value rejection, outlier capping"],
  ["EDA", "Distribution and correlation review of financial ratios"],
  ["Feature engineering", "Savings rate, expense ratio, emergency months, debt burden, buffers"],
  ["Model training", "Logistic Regression, Random Forest, Gradient Boosting, XGBoost"],
  ["Evaluation", "Accuracy, F1, ROC-AUC with stratified cross-validation"],
  ["Explainability", "Additive SHAP contributions + global importance"],
  ["Prediction", "Risk class with calibrated confidence"],
  ["Recommendation", "Rule-guarded allocation and goal plan"],
];

function XaiPage() {
  const { risk, health } = useAnalysis();
  const local = risk.contributions.map((c) => ({ name: c.label, value: Number(c.contribution.toFixed(3)), display: c.display }));
  const global = globalImportance().map((g) => ({ name: g.label, value: Number(g.importance.toFixed(3)) }));
  const radar = health.metrics.map((m) => ({ metric: m.label, score: Math.round(m.score) }));

  return (
    <AppShell title="Explainable AI Dashboard" subtitle="Local and global explanations for the deployed model">
      <Alert className="mb-6">
        <Brain className="size-4" />
        <AlertTitle>Plain-language explanation</AlertTitle>
        <AlertDescription>{risk.narrative}</AlertDescription>
      </Alert>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Local explanation (this prediction)</CardTitle>
            <CardDescription>Signed contribution of each feature towards {risk.riskClass}; base value {risk.baseValue.toFixed(2)}</CardDescription>
          </CardHeader>
          <CardContent className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={local} layout="vertical" margin={{ left: 50 }}>
                <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis type="category" dataKey="name" width={140} stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip />
                <Bar dataKey="value" radius={4}>
                  {local.map((d) => (
                    <Cell key={d.name} fill={d.value >= 0 ? "var(--color-chart-2)" : "var(--color-chart-5)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Global feature importance</CardTitle>
            <CardDescription>Mean absolute model weight across all risk classes</CardDescription>
          </CardHeader>
          <CardContent className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={global} layout="vertical" margin={{ left: 50 }}>
                <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis type="category" dataKey="name" width={140} stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip />
                <Bar dataKey="value" fill="var(--color-chart-1)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Feature values used</CardTitle>
            <CardDescription>Engineered inputs and their effect</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Feature</TableHead>
                  <TableHead>Your value</TableHead>
                  <TableHead className="text-right">Contribution</TableHead>
                  <TableHead>Direction</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {risk.contributions.map((c) => (
                  <TableRow key={c.feature}>
                    <TableCell className="font-medium">{c.label}</TableCell>
                    <TableCell>{c.display}</TableCell>
                    <TableCell className="text-right">{c.contribution.toFixed(3)}</TableCell>
                    <TableCell className={c.contribution >= 0 ? "text-success" : "text-destructive"}>
                      {c.contribution >= 0 ? `pushes towards ${risk.riskClass}` : "pushes away"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="grid gap-6">
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle>Financial health fingerprint</CardTitle>
              <CardDescription>Sub-scores across the five health pillars</CardDescription>
            </CardHeader>
            <CardContent className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radar}>
                  <PolarGrid stroke="var(--color-border)" />
                  <PolarAngleAxis dataKey="metric" fontSize={11} stroke="var(--color-muted-foreground)" />
                  <Radar dataKey="score" stroke="var(--color-chart-1)" fill="var(--color-chart-1)" fillOpacity={0.35} />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="card-elevated">
            <CardHeader>
              <CardTitle>ML pipeline & evaluation</CardTitle>
              <CardDescription>Training is offline; the app performs inference only</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <ol className="space-y-2 text-sm">
                {PIPELINE.map(([step, detail], i) => (
                  <li key={step} className="flex gap-3">
                    <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-medium">{i + 1}</span>
                    <span>
                      <span className="font-medium">{step}</span>
                      <span className="text-muted-foreground"> — {detail}</span>
                    </span>
                  </li>
                ))}
              </ol>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Model</TableHead>
                    <TableHead className="text-right">Accuracy</TableHead>
                    <TableHead className="text-right">ROC-AUC</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {MODEL_LEADERBOARD.map((m) => (
                    <TableRow key={m.model}>
                      <TableCell>{m.model}</TableCell>
                      <TableCell className="text-right">{pct(m.accuracy, 1)}</TableCell>
                      <TableCell className="text-right">{pct(m.rocAuc, 1)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
