import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from "recharts";
import { AppShell } from "@/components/app/AppShell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useProfile } from "@/lib/finance/store";
import { analyseHealth, currency, pct, predictRisk, projectWealth, recommend } from "@/lib/finance/engine";

export const Route = createFileRoute("/simulator")({
  head: () => ({
    meta: [
      { title: "What-If Simulator — FinAdvisor XAI" },
      { name: "description", content: "Change income, expenses, SIP amount, horizon or risk and watch outcomes update live." },
      { property: "og:title", content: "What-If Simulator — FinAdvisor XAI" },
      { property: "og:description", content: "Interactive scenario testing for your financial health and projected corpus." },
    ],
  }),
  component: SimulatorPage,
});

function SimulatorPage() {
  const { profile } = useProfile();
  const [income, setIncome] = useState(profile.monthlyIncome);
  const [expenses, setExpenses] = useState(profile.monthlyExpenses);
  const [sip, setSip] = useState(profile.monthlyInvestment);
  const [horizon, setHorizon] = useState(profile.horizonYears);
  const [risk, setRisk] = useState(profile.riskTolerance);

  const base = useMemo(() => {
    const health = analyseHealth(profile);
    const r = predictRisk(profile);
    const rec = recommend(profile, r);
    return { health, risk: r, rec };
  }, [profile]);

  const scenario = useMemo(() => {
    const p = {
      ...profile,
      monthlyIncome: income,
      monthlyExpenses: expenses,
      monthlyInvestment: sip,
      horizonYears: horizon,
      riskTolerance: risk,
    };
    const health = analyseHealth(p);
    const r = predictRisk(p);
    const rec = recommend(p, r);
    return { profile: p, health, risk: r, rec };
  }, [profile, income, expenses, sip, horizon, risk]);

  const years = Math.max(horizon, profile.horizonYears);
  const basePts = projectWealth(profile.existingInvestments, profile.monthlyInvestment, base.rec.expectedReturn, years);
  const scenPts = projectWealth(profile.existingInvestments, sip, scenario.rec.expectedReturn, years);
  const chart = basePts.map((b, i) => ({ year: b.year, current: b.value, scenario: scenPts[i]?.value ?? 0 }));

  const reset = () => {
    setIncome(profile.monthlyIncome);
    setExpenses(profile.monthlyExpenses);
    setSip(profile.monthlyInvestment);
    setHorizon(profile.horizonYears);
    setRisk(profile.riskTolerance);
  };

  return (
    <AppShell title="What-If Financial Simulator" subtitle="Test scenarios without changing your saved profile">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Scenario controls</CardTitle>
            <CardDescription>Drag to explore outcomes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Control label="Monthly income" value={currency(income)}>
              <Slider value={[income]} min={0} max={Math.max(300000, profile.monthlyIncome * 3)} step={1000} onValueChange={([v]) => setIncome(v ?? 0)} />
            </Control>
            <Control label="Monthly expenses" value={currency(expenses)}>
              <Slider value={[expenses]} min={0} max={Math.max(200000, profile.monthlyExpenses * 3)} step={1000} onValueChange={([v]) => setExpenses(v ?? 0)} />
            </Control>
            <Control label="Monthly investment" value={currency(sip)}>
              <Slider value={[sip]} min={0} max={Math.max(100000, profile.monthlyInvestment * 4)} step={1000} onValueChange={([v]) => setSip(v ?? 0)} />
            </Control>
            <Control label="Investment horizon" value={`${horizon} yrs`}>
              <Slider value={[horizon]} min={1} max={40} step={1} onValueChange={([v]) => setHorizon(v ?? 1)} />
            </Control>
            <Control label="Risk tolerance" value={`${risk}/10`}>
              <Slider value={[risk]} min={1} max={10} step={1} onValueChange={([v]) => setRisk(v ?? 5)} />
            </Control>
            <Button variant="outline" className="w-full" onClick={reset}>Reset to saved profile</Button>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:col-span-2">
          <Card className="card-elevated">
            <CardHeader>
              <CardTitle>Impact summary</CardTitle>
              <CardDescription>Scenario compared with your saved profile</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Delta label="Health score" base={`${base.health.score}`} now={`${scenario.health.score}`} up={scenario.health.score >= base.health.score} />
              <Delta label="Savings rate" base={pct(base.health.savingsRate)} now={pct(scenario.health.savingsRate)} up={scenario.health.savingsRate >= base.health.savingsRate} />
              <Delta label="Surplus" base={currency(base.health.surplus)} now={currency(scenario.health.surplus)} up={scenario.health.surplus >= base.health.surplus} />
              <Delta label="Risk class" base={base.risk.riskClass} now={scenario.risk.riskClass} up={scenario.risk.riskClass !== base.risk.riskClass} />
            </CardContent>
          </Card>

          <Card className="card-elevated">
            <CardHeader>
              <CardTitle>Projected corpus comparison</CardTitle>
              <CardDescription>
                Scenario return {pct(scenario.rec.expectedReturn)} vs current {pct(base.rec.expectedReturn)}
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chart}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="year" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickFormatter={(v: number) => `${(v / 100000).toFixed(0)}L`} />
                  <Tooltip formatter={(v: number) => currency(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" dataKey="current" name="Current plan" stroke="var(--color-chart-1)" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="scenario" name="Scenario" stroke="var(--color-chart-2)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}

function Control({ label, value, children }: { label: string; value: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        <span className="text-sm font-medium">{value}</span>
      </div>
      {children}
    </div>
  );
}

function Delta({ label, base, now, up }: { label: string; base: string; now: string; up: boolean }) {
  const changed = base !== now;
  return (
    <div className="rounded-xl border border-border p-4">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="font-display text-xl font-semibold">{now}</p>
      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
        <span>was {base}</span>
        {changed && <Badge variant={up ? "default" : "destructive"}>{up ? "improved" : "lower"}</Badge>}
      </div>
    </div>
  );
}
