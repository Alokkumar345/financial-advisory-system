import { createFileRoute } from "@tanstack/react-router";
import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/app/AppShell";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAnalysis } from "@/lib/finance/store";
import { MODEL_LEADERBOARD, RISK_CLASSES, pct } from "@/lib/finance/engine";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/risk")({
  head: () => ({
    meta: [
      { title: "Risk Assessment — FinAdvisor XAI" },
      { name: "description", content: "ML-based investor risk profiling with per-feature explanations and model comparison." },
      { property: "og:title", content: "Risk Assessment — FinAdvisor XAI" },
      { property: "og:description", content: "See your predicted risk class, confidence and the factors that drove it." },
    ],
  }),
  component: RiskPage,
});

function RiskPage() {
  const { risk } = useAnalysis();
  const probData = RISK_CLASSES.map((c) => ({ name: c, value: risk.probabilities[c] * 100 }));
  const contribData = risk.contributions.slice(0, 7).map((c) => ({
    name: c.label,
    value: Number(c.contribution.toFixed(3)),
    display: c.display,
  }));

  return (
    <AppShell title="Investment Risk Profiling" subtitle="Multinomial classifier over engineered financial features">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-1">
          <CardHeader>
            <CardTitle>Predicted risk profile</CardTitle>
            <CardDescription>Model output for your current profile</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <Badge className="px-3 py-1 text-base">{risk.riskClass}</Badge>
            <div>
              <p className="text-sm text-muted-foreground">Confidence</p>
              <Progress value={risk.confidence * 100} className="mt-2" />
              <p className="mt-1 text-sm font-medium">{pct(risk.confidence, 1)}</p>
            </div>
            <div className="space-y-2">
              {RISK_CLASSES.map((c) => (
                <div key={c} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{c}</span>
                  <span className="font-medium">{pct(risk.probabilities[c], 1)}</span>
                </div>
              ))}
            </div>
            <p className="rounded-lg bg-secondary p-3 text-sm">{risk.narrative}</p>
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Class probabilities</CardTitle>
            <CardDescription>Softmax over class scores</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={probData}>
                <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis unit="%" stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip formatter={(v: number) => `${v.toFixed(1)}%`} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {probData.map((d) => (
                    <Cell key={d.name} fill={d.name === risk.riskClass ? "var(--color-chart-1)" : "var(--color-chart-2)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Why this prediction</CardTitle>
            <CardDescription>Signed SHAP-style contributions towards {risk.riskClass}</CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={contribData} layout="vertical" margin={{ left: 40 }}>
                <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis type="category" dataKey="name" width={130} stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip />
                <Bar dataKey="value" radius={4}>
                  {contribData.map((d) => (
                    <Cell key={d.name} fill={d.value >= 0 ? "var(--color-chart-2)" : "var(--color-chart-5)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Model comparison</CardTitle>
            <CardDescription>Offline evaluation on the training dataset</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Model</TableHead>
                  <TableHead className="text-right">Acc</TableHead>
                  <TableHead className="text-right">F1</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {MODEL_LEADERBOARD.map((m) => (
                  <TableRow key={m.model}>
                    <TableCell className="text-sm">{m.model}</TableCell>
                    <TableCell className="text-right">{(m.accuracy * 100).toFixed(1)}%</TableCell>
                    <TableCell className="text-right">{(m.f1 * 100).toFixed(1)}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="mt-3 text-xs text-muted-foreground">
              The deployed model is the interpretable linear classifier: near-identical accuracy with exact,
              additive explanations.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}