import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { Bot, Send, User } from "lucide-react";
import { AppShell } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { askAssistant } from "@/lib/ai.functions";
import { useAnalysis, useProfile } from "@/lib/finance/store";
import { currency, pct } from "@/lib/finance/engine";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "AI Financial Assistant — FinAdvisor XAI" },
      { name: "description", content: "Ask questions about your dashboard, metrics, risk profile and recommendations." },
      { property: "og:title", content: "AI Financial Assistant — FinAdvisor XAI" },
      { property: "og:description", content: "A cautious, explanation-first assistant for your financial data." },
    ],
  }),
  component: AssistantPage,
});

const SUGGESTIONS = [
  "Explain my financial health score in simple terms.",
  "Why did the model classify my risk profile this way?",
  "What should I fix first to improve my plan?",
  "How does my allocation match my goals?",
];

interface Msg { role: "user" | "assistant"; content: string }

function AssistantPage() {
  const { profile } = useProfile();
  const { health, risk, recommendation } = useAnalysis();
  const ask = useServerFn(askAssistant);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Hi! I can explain your dashboard, financial metrics, the risk model and its explanations. I share educational information only — for regulated advice, please consult a qualified financial professional. What would you like to understand?",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const context = [
    `Name: ${profile.name}, age ${profile.age}, occupation ${profile.occupation}, ${profile.dependents} dependents.`,
    `Monthly income ${currency(profile.monthlyIncome)}, expenses ${currency(profile.monthlyExpenses)}, EMI ${currency(profile.monthlyEmi)}, surplus ${currency(health.surplus)}.`,
    `Savings ${currency(profile.currentSavings)}, investments ${currency(profile.existingInvestments)}, SIP ${currency(profile.monthlyInvestment)}.`,
    `Health score ${health.score}/100 (${health.grade}); savings rate ${pct(health.savingsRate)}; emergency fund ${health.emergencyMonths.toFixed(1)} months.`,
    `Risk profile ${risk.riskClass} at ${pct(risk.confidence)} confidence. Top drivers: ${risk.contributions.slice(0, 4).map((c) => `${c.label} (${c.display})`).join(", ")}.`,
    `Allocation: ${recommendation.allocation.map((a) => `${a.asset} ${a.percent}%`).join(", ")}; expected return ${pct(recommendation.expectedReturn)}.`,
    `Goals: ${profile.goals.map((g) => `${g.name} ${currency(g.targetAmount)} in ${g.years}y`).join("; ") || "none"}.`,
  ].join("\n");

  const send = async (text: string) => {
    const question = text.trim();
    if (!question || busy) return;
    const next: Msg[] = [...messages, { role: "user", content: question }];
    setMessages(next);
    setInput("");
    setBusy(true);
    const res = await ask({
      data: { messages: next.filter((m) => m.content).slice(-12), context },
    });
    setMessages((m) => [
      ...m,
      { role: "assistant", content: res.ok ? res.text : `⚠️ ${res.error}` },
    ]);
    setBusy(false);
    requestAnimationFrame(() => endRef.current?.scrollIntoView({ behavior: "smooth" }));
  };

  return (
    <AppShell title="AI Financial Assistant" subtitle="Explanations in plain language — never guaranteed advice">
      <Card className="card-elevated mx-auto flex h-[70vh] max-w-3xl flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Bot className="size-5 text-primary" /> Assistant</CardTitle>
          <CardDescription>Aware of your profile, health score, risk prediction and allocation</CardDescription>
        </CardHeader>
        <CardContent className="flex min-h-0 flex-1 flex-col gap-4">
          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
                {m.role === "assistant" && (
                  <span className="mt-1 flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary"><Bot className="size-4" /></span>
                )}
                <p className={`max-w-[80%] whitespace-pre-wrap rounded-xl px-4 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
                  {m.content}
                </p>
                {m.role === "user" && (
                  <span className="mt-1 flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary"><User className="size-4" /></span>
                )}
              </div>
            ))}
            {busy && <p className="text-sm text-muted-foreground">Thinking…</p>}
            <div ref={endRef} />
          </div>

          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <Button key={s} variant="outline" size="sm" className="text-xs" onClick={() => void send(s)} disabled={busy}>
                {s}
              </Button>
            ))}
          </div>

          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
          >
            <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about your finances…" disabled={busy} />
            <Button type="submit" disabled={busy || !input.trim()}><Send className="size-4" /></Button>
          </form>
        </CardContent>
      </Card>
    </AppShell>
  );
}
