import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useProfile } from "@/lib/finance/store";
import { currency } from "@/lib/finance/engine";
import type { FinancialProfile } from "@/lib/finance/types";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Financial Profile — FinAdvisor XAI" },
      { name: "description", content: "Capture income, expenses, savings, horizon and risk tolerance to drive the models." },
      { property: "og:title", content: "Financial Profile — FinAdvisor XAI" },
      { property: "og:description", content: "Update your financial inputs and instantly refresh every analysis." },
    ],
  }),
  component: ProfilePage,
});

type NumericKey =
  | "age"
  | "dependents"
  | "monthlyIncome"
  | "monthlyExpenses"
  | "monthlyEmi"
  | "currentSavings"
  | "existingInvestments"
  | "monthlyInvestment"
  | "horizonYears";

const FIELDS: { key: NumericKey; label: string; max: number; hint?: string }[] = [
  { key: "age", label: "Age (years)", max: 100 },
  { key: "dependents", label: "Dependents", max: 10 },
  { key: "monthlyIncome", label: "Monthly income", max: 10_000_000 },
  { key: "monthlyExpenses", label: "Monthly expenses", max: 10_000_000 },
  { key: "monthlyEmi", label: "Monthly EMI / debt payment", max: 10_000_000 },
  { key: "currentSavings", label: "Liquid savings", max: 1_000_000_000 },
  { key: "existingInvestments", label: "Existing investments", max: 1_000_000_000 },
  { key: "monthlyInvestment", label: "Monthly investable amount", max: 10_000_000 },
  { key: "horizonYears", label: "Investment horizon (years)", max: 50 },
];

function ProfilePage() {
  const { profile, updateProfile, resetProfile } = useProfile();
  const [draft, setDraft] = useState<FinancialProfile>(profile);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const setNum = (key: NumericKey, raw: string, max: number) => {
    const value = raw === "" ? 0 : Number(raw);
    setDraft((d) => ({ ...d, [key]: value }));
    setErrors((e) => {
      const next = { ...e };
      if (!Number.isFinite(value) || value < 0) next[key] = "Value cannot be negative.";
      else if (value > max) next[key] = `Value looks too large (max ${max.toLocaleString("en-IN")}).`;
      else delete next[key];
      return next;
    });
  };

  const save = (): void => {
    if (draft.age < 16) {
      toast.error("Age must be at least 16.");
      return;
    }
    if (draft.monthlyIncome <= 0) {
      toast.error("Monthly income must be greater than zero.");
      return;
    }
    if (draft.monthlyExpenses + draft.monthlyEmi > draft.monthlyIncome * 3) {
      toast.error("Expenses plus EMI look unrealistic versus income.");
      return;
    }
    if (Object.keys(errors).length) {
      toast.error("Fix the highlighted fields first.");
      return;
    }
    updateProfile(draft);
    toast.success("Profile updated — all analyses refreshed.");
  };

  const surplus = draft.monthlyIncome - draft.monthlyExpenses - draft.monthlyEmi;

  return (
    <AppShell title="User Financial Profile" subtitle="These inputs feed every model in the system">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Financial inputs</CardTitle>
            <CardDescription>All amounts are monthly unless stated otherwise. Negative values are rejected.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="occupation">Occupation</Label>
              <Input id="occupation" value={draft.occupation} onChange={(e) => setDraft({ ...draft, occupation: e.target.value })} />
            </div>
            {FIELDS.map((f) => (
              <div key={f.key} className="space-y-2">
                <Label htmlFor={f.key}>{f.label}</Label>
                <Input
                  id={f.key}
                  type="number"
                  min={0}
                  value={String(draft[f.key])}
                  onChange={(e) => setNum(f.key, e.target.value, f.max)}
                  aria-invalid={Boolean(errors[f.key])}
                />
                {errors[f.key] && <p className="text-xs text-destructive">{errors[f.key]}</p>}
              </div>
            ))}

            <div className="space-y-3 sm:col-span-2">
              <Label>Risk tolerance — {draft.riskTolerance}/10</Label>
              <Slider value={[draft.riskTolerance]} min={1} max={10} step={1} onValueChange={([v]) => setDraft({ ...draft, riskTolerance: v ?? 5 })} />
              <Label>Income stability — {draft.incomeStability}/10</Label>
              <Slider value={[draft.incomeStability]} min={1} max={10} step={1} onValueChange={([v]) => setDraft({ ...draft, incomeStability: v ?? 5 })} />
            </div>

            <div className="flex flex-wrap gap-3 sm:col-span-2">
              <Button onClick={save}>Save profile</Button>
              <Button variant="outline" onClick={() => setDraft(profile)}>Revert changes</Button>
              <Button
                variant="ghost"
                onClick={() => {
                  resetProfile();
                  toast.info("Loaded the sample profile.");
                }}
              >
                Load sample data
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="card-elevated h-fit">
          <CardHeader>
            <CardTitle>Live preview</CardTitle>
            <CardDescription>Computed from the current form values</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row label="Monthly surplus" value={currency(surplus)} />
            <Row label="Savings rate" value={`${draft.monthlyIncome > 0 ? ((surplus / draft.monthlyIncome) * 100).toFixed(1) : "0.0"}%`} />
            <Row label="Net worth" value={currency(draft.currentSavings + draft.existingInvestments)} />
            <Row label="Horizon" value={`${draft.horizonYears} years`} />
            <p className="pt-2 text-xs text-muted-foreground">
              Inputs are validated for negative and implausible values before they reach the models.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-border pb-2 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}