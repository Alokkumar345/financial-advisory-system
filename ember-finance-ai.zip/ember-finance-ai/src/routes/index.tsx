import { createFileRoute, Link } from "@tanstack/react-router";
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, Bar, BarChart, XAxis, YAxis, CartesianGrid } from "recharts";
import { ArrowUpRight, Banknote, PiggyBank, Receipt, ShieldCheck, TrendingUp } from "lucide-react";
import { AppShell } from "@/components/app/AppShell";
import { StatCard } from "@/components/app/StatCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAnalysis, useProfile } from "@/lib/finance/store";
import { currency, pct, planGoal } from "@/lib/finance/engine";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Financial Health Dashboard — FinAdvisor XAI" },
      { name: "description", content: "AI-driven personalised financial planning with explainable risk profiling, allocation and goal tracking." },
      { property: "og:title", content: "Financial Health Dashboard — FinAdvisor XAI" },
      { property: "og:description", content: "Track income, savings rate, health score, risk profile and recommended allocation in one dashboard." },
    ],
  }),
  component: Dashboard,
});

const COLORS = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)", "var(--color-muted-foreground)"];

function Dashboard() {
  const { profile } = useProfile();
  const { health, risk, recommendation } = useAnalysis();
  const plans = profile.goals.map((g) => planGoal(g, recommendation.expectedReturn, health.surplus));

  return (
    <AppShell title="Financial Health Dashboard" subtitle={`Welcome back, ${profile.name}`}>
      <div className="gradient-hero mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl p-6 text-primary-foreground">
        <div>
          <p className="text-xs uppercase tracking-wide text-primary-foreground/70">Overall financial health</p>
          <p className="font-display text-4xl font-semibold">{health.score}/100 · {health.grade}</p>
          <p className="mt-1 max-w-xl text-sm text-primary-foreground/80">{risk.narrative}</p>
        </div>
        <Button asChild variant="secondary">
          <Link to="/recommendations">View investment plan <ArrowUpRight className="size-4" /></Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Monthly income" value={currency(profile.monthlyIncome)} icon={<Banknote className="size-4" />} />
        <StatCard label="Monthly expenses" value={currency(profile.monthlyExpenses + profile.monthlyEmi)} hint="Includes EMI" icon={<Receipt className="size-4" />} />
        <StatCard label="Monthly savings" value={currency(health.surplus)} tone={health.surplus > 0 ? "success" : "destructive"} icon={<PiggyBank className="size-4" />} />
        <StatCard label="Savings rate" value={pct(health.savingsRate)} hint="Target 20–30%" tone={health.savingsRate >= 0.2 ? "success" : "warning"} icon={<TrendingUp className="size-4" />} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Health breakdown</CardTitle>
            <CardDescription>Weighted sub-scores across five pillars</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {health.metrics.map((m) => (
              <div key={m.key}>
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{m.label}</span>
                  <span className="text-muted-foreground">{m.display} · {Math.round(m.score)}/100</span>
                </div>
                <Progress value={m.score} className="mt-2" />
                <p className="mt-1 text-xs text-muted-foreground">{m.hint}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><ShieldCheck className="size-4 text-primary" /> Risk & allocation</CardTitle>
            <CardDescription>Predicted profile: {risk.riskClass} ({pct(risk.confidence, 0)} confidence)</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={recommendation.allocation} dataKey="percent" nameKey="asset" innerRadius={45} outerRadius={80} paddingAngle={2}>
                  {recommendation.allocation.map((a, i) => <Cell key={a.asset} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Tooltip formatter={(v: number) => `${v}%`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Strengths</CardTitle>
            <CardDescription>What's working well</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {health.strengths.map((m) => (
              <p key={m.key} className="flex items-center justify-between">
                <span>{m.label}</span>
                <Badge variant="secondary">{m.display}</Badge>
              </p>
            ))}
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Areas to improve</CardTitle>
            <CardDescription>Highest-impact fixes first</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {health.weaknesses.map((m) => (
              <p key={m.key} className="flex items-center justify-between gap-2">
                <span>{m.label}</span>
                <Badge variant="destructive">{m.display}</Badge>
              </p>
            ))}
          </CardContent>
        </Card>

        <Card className="card-elevated">
          <CardHeader>
            <CardTitle>Goal progress</CardTitle>
            <CardDescription>Funding status today</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {plans.map((p) => (
              <div key={p.goal.id}>
                <div className="flex justify-between text-sm">
                  <span>{p.goal.name}</span>
                  <span className="text-muted-foreground">{currency(p.requiredMonthly)}/mo</span>
                </div>
                <Progress className="mt-1" value={Math.min(100, (p.goal.saved / Math.max(1, p.goal.targetAmount)) * 100)} />
              </div>
            ))}
            {plans.length === 0 && <p className="text-sm text-muted-foreground">No goals added yet.</p>}
          </CardContent>
        </Card>

        <Card className="card-elevated lg:col-span-3">
          <CardHeader>
            <CardTitle>Top model drivers</CardTitle>
            <CardDescription>Factors that shaped your {risk.riskClass} classification</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={risk.contributions.slice(0, 6).map((c) => ({ name: c.label, value: Number(c.contribution.toFixed(3)) }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {risk.contributions.slice(0, 6).map((c) => (
                    <Cell key={c.feature} fill={c.contribution >= 0 ? "var(--color-chart-2)" : "var(--color-chart-5)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
