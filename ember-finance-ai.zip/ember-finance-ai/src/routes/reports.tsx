import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAnalysis, useProfile } from "@/lib/finance/store";
import { currency, pct, planGoal } from "@/lib/finance/engine";
import { Download, Printer } from "lucide-react";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports & Export — FinAdvisor XAI" },
      { name: "description", content: "Export your financial summary, risk profile and allocation as JSON, CSV or PDF." },
      { property: "og:title", content: "Reports & Export — FinAdvisor XAI" },
      { property: "og:description", content: "A shareable summary of your plan, metrics and model explanations." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const { profile } = useProfile();
  const { health, risk, recommendation } = useAnalysis();
  const plans = profile.goals.map((g) => planGoal(g, recommendation.expectedReturn, health.surplus));

  const report = { profile, health, risk, recommendation, generatedAt: new Date().toISOString() };

  const download = (content: string, filename: string, type: string) => {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const csv = [
    "section,label,value",
    `profile,name,${profile.name}`,
    `profile,monthly income,${profile.monthlyIncome}`,
    `profile,monthly expenses,${profile.monthlyExpenses}`,
    `health,score,${health.score}`,
    `health,savings rate,${(health.savingsRate * 100).toFixed(1)}%`,
    `health,emergency months,${health.emergencyMonths.toFixed(1)}`,
    `risk,class,${risk.riskClass}`,
    `risk,confidence,${(risk.confidence * 100).toFixed(1)}%`,
    ...recommendation.allocation.map((a) => `allocation,${a.asset},${a.percent}%`),
    ...plans.map((p) => `goal,${p.goal.name},required ${Math.round(p.requiredMonthly)}/month`),
  ].join("\n");

  return (
    <AppShell title="Reports & Export" subtitle="Share or archive your full financial summary">
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="card-elevated lg:col-span-2">
          <CardHeader>
            <CardTitle>Summary report</CardTitle>
            <CardDescription>Generated {new Date().toLocaleString()}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-sm">
            <section>
              <h3 className="mb-2 font-semibold">Profile</h3>
              <p className="text-muted-foreground">
                {profile.name}, {profile.age} · {profile.occupation} · {profile.dependents} dependents ·
                horizon {profile.horizonYears} years · risk tolerance {profile.riskTolerance}/10
              </p>
            </section>
            <section>
              <h3 className="mb-2 font-semibold">Financial health</h3>
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Metric</TableHead><TableHead>Value</TableHead><TableHead className="text-right">Score</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {health.metrics.map((m) => (
                    <TableRow key={m.key}>
                      <TableCell>{m.label}</TableCell>
                      <TableCell>{m.display}</TableCell>
                      <TableCell className="text-right">{Math.round(m.score)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </section>
            <section>
              <h3 className="mb-2 font-semibold">Risk & allocation</h3>
              <p className="text-muted-foreground">{risk.narrative}</p>
              <p className="mt-2">
                {recommendation.allocation.map((a) => `${a.asset} ${a.percent}%`).join(" · ")} — expected return {pct(recommendation.expectedReturn)}
              </p>
            </section>
            <section>
              <h3 className="mb-2 font-semibold">Goals</h3>
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Goal</TableHead><TableHead>Target</TableHead><TableHead className="text-right">Required / month</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {plans.map((p) => (
                    <TableRow key={p.goal.id}>
                      <TableCell>{p.goal.name}</TableCell>
                      <TableCell>{currency(p.goal.targetAmount)} in {p.goal.years}y</TableCell>
                      <TableCell className="text-right">{currency(p.requiredMonthly)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </section>
            <p className="text-xs text-muted-foreground">
              Disclaimer: educational decision-support output. Not investment advice or a guarantee of returns.
            </p>
          </CardContent>
        </Card>

        <Card className="card-elevated h-fit">
          <CardHeader>
            <CardTitle>Export</CardTitle>
            <CardDescription>Download or print your report</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" onClick={() => download(JSON.stringify(report, null, 2), "financial-report.json", "application/json")}>
              <Download className="size-4" /> Download JSON
            </Button>
            <Button variant="outline" className="w-full" onClick={() => download(csv, "financial-report.csv", "text/csv")}>
              <Download className="size-4" /> Download CSV
            </Button>
            <Button variant="outline" className="w-full" onClick={() => window.print()}>
              <Printer className="size-4" /> Print / Save as PDF
            </Button>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
