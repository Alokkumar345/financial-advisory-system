import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useProfile } from "@/lib/finance/store";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — FinAdvisor XAI" },
      { name: "description", content: "Sign in or register to access your explainable financial planning dashboard." },
      { property: "og:title", content: "Sign in — FinAdvisor XAI" },
      { property: "og:description", content: "Access your personalised, explainable financial planning workspace." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { signIn, updateProfile } = useProfile();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = (mode: "login" | "register") => {
    if (!email.includes("@")) return setError("Enter a valid email address.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    if (mode === "register" && name.trim().length < 2) return setError("Enter your full name.");
    setError("");
    const displayName = name.trim() || email.split("@")[0]!;
    signIn({ name: displayName, email });
    if (mode === "register") updateProfile({ name: displayName });
    navigate({ to: "/profile" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="gradient-hero hidden flex-col justify-between p-12 text-primary-foreground lg:flex">
        <div className="flex items-center gap-2">
          <Activity className="size-5" />
          <span className="font-display font-semibold">FinAdvisor XAI</span>
        </div>
        <div className="space-y-4">
          <h2 className="font-display text-4xl font-semibold leading-tight">
            Explainable, personalised financial planning
          </h2>
          <p className="max-w-md text-sm text-primary-foreground/80">
            Financial health scoring, ML risk profiling with SHAP-style explanations, allocation
            guidance, goal planning and what-if simulation — all in one workspace.
          </p>
        </div>
        <p className="text-xs text-primary-foreground/70">
          Educational decision-support tool. Not regulated financial advice.
        </p>
      </div>

      <div className="flex items-center justify-center bg-background p-6">
        <Card className="card-elevated w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl">Welcome</CardTitle>
            <CardDescription>
              Demo authentication — your profile is stored locally in this browser.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login">
              <TabsList className="w-full">
                <TabsTrigger value="login" className="flex-1">Login</TabsTrigger>
                <TabsTrigger value="register" className="flex-1">Register</TabsTrigger>
              </TabsList>

              {(["login", "register"] as const).map((mode) => (
                <TabsContent key={mode} value={mode} className="space-y-4 pt-4">
                  {mode === "register" && (
                    <div className="space-y-2">
                      <Label htmlFor={`${mode}-name`}>Full name</Label>
                      <Input id={`${mode}-name`} value={name} onChange={(e) => setName(e.target.value)} placeholder="Alok Kumar" />
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor={`${mode}-email`}>Email</Label>
                    <Input id={`${mode}-email`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`${mode}-password`}>Password</Label>
                    <Input id={`${mode}-password`} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
                  </div>
                  {error && <p className="text-sm text-destructive">{error}</p>}
                  <Button className="w-full" onClick={() => submit(mode)}>
                    {mode === "login" ? "Sign in" : "Create account"}
                  </Button>
                  <Button variant="ghost" className="w-full" onClick={() => navigate({ to: "/" })}>
                    Continue with sample data
                  </Button>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}