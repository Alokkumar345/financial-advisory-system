# Insightful Finance AI

LINK: https://ember-finance-ai.lovable.app/

Project Prompt

Build a full-stack AI-Driven Personalized Financial Planning and Investment Advisory System Using Explainable Machine Learning.

The system should help users understand their financial situation and receive personalized, explainable recommendations based on their income, expenses, savings, financial goals, risk tolerance, age, investment horizon, and existing investments.

Core Features

User Profile & Financial Data

User registration/login.

Collect income, monthly expenses, savings, age, occupation, financial goals, investment amount, investment duration, and risk tolerance.

Allow users to update their financial information.

Financial Health Analysis

Calculate savings rate, expense-to-income ratio, emergency-fund status, debt burden, and overall financial health score.

Display the results using simple charts and dashboards.

Identify major financial strengths and weaknesses.

Investment Risk Profiling

Classify users into risk categories such as:

Conservative

Moderate

Aggressive

Use a machine-learning model to predict the user's risk profile.

Explain which financial factors influenced the prediction.

Personalized Investment Recommendation

Recommend suitable asset classes such as:

Equity

Debt

Mutual Funds

Fixed Deposits

Gold

Other configurable investment categories

Generate an allocation based on the user's financial profile, risk tolerance, goals, and investment horizon.

Do not present recommendations as guaranteed returns or personalized regulated financial advice; clearly label them as educational decision support.

Explainable Machine Learning

Use SHAP or another explainability method.

Show why the model produced a particular prediction or recommendation.

Display the most important factors using charts.

Example:
“Your risk profile is Moderate mainly because of your income stability, investment horizon, monthly savings, and risk tolerance.”

Financial Goal Planning

Allow users to create goals such as:

Buying a house

Higher education

Emergency fund

Retirement

Car purchase

Estimate the required monthly investment for each goal.

Compare the required amount with the user's current savings capacity.

What-If Financial Simulator

Allow users to change income, expenses, investment amount, investment duration, or risk level.

Show how these changes affect financial health and projected goal achievement.

Display results using interactive charts.

AI Financial Assistant

Add a simple chatbot interface for financial questions.

The assistant should explain the dashboard, financial metrics, model predictions, and recommendations in simple language.

It should avoid claiming certainty and should encourage users to consult a qualified financial professional for regulated advice.

Machine Learning Pipeline

Create an end-to-end ML pipeline:

Data Collection → Data Cleaning → EDA → Feature Engineering → Model Training → Model Evaluation → Explainability → Prediction → Recommendation

Use suitable algorithms such as:

Random Forest

XGBoost

Logistic Regression

Gradient Boosting

K-Means for optional customer segmentation

Compare multiple models and select the best-performing model using appropriate evaluation metrics.

Explainability Requirements

Integrate:

SHAP feature importance

Individual prediction explanation

Global feature importance

Simple natural-language explanations

Example output:

Predicted Risk Profile: Moderate
Important factors: investment horizon, monthly savings, income stability, and risk tolerance.

Technology Stack

Frontend: Streamlit
Backend: FastAPI
Programming: Python
Data Processing: Pandas, NumPy
Visualization: Matplotlib, Seaborn, Plotly
Machine Learning: Scikit-learn, XGBoost
Explainable AI: SHAP
Database: MongoDB or MySQL
Model Storage: Joblib/Pickle
API Testing: Postman
Version Control: Git and GitHub
Deployment: Docker + a suitable cloud platform

Required Pages

Create these main pages:

Login/Register

User Financial Profile

Financial Health Dashboard

Risk Assessment

Investment Recommendation

Financial Goal Planner

What-If Simulator

Explainable AI Dashboard

AI Financial Assistant

Reports/Export

Dashboard Design

Create a professional, modern, responsive dashboard containing:

Income

Expenses

Savings

Savings Rate

Financial Health Score

Risk Profile

Recommended Allocation

Goal Progress

Important Financial Insights

Use clean cards, charts, tables, and understandable explanations.

Project Structure

Create a production-style folder structure:

financial-advisory-system/
│
├── frontend/
├── backend/
├── data/
├── models/
├── notebooks/
├── src/
│   ├── data_processing/
│   ├── feature_engineering/
│   ├── training/
│   ├── prediction/
│   ├── explainability/
│   └── recommendation/
├── tests/
├── requirements.txt
├── Dockerfile
├── README.md
└── .gitignore


Important Requirements

Use clean and modular Python code.

Add proper error handling and input validation.

Prevent invalid financial values such as negative income.

Keep ML training separate from prediction/inference.

Save trained models and preprocessing objects.

Provide sample/dummy data for testing.

Add comments where useful.

Create API endpoints for prediction, risk assessment, financial health analysis, and recommendations.

Make the UI suitable for a college-level major project and portfolio/GitHub presentation.

Include README documentation with setup instructions, architecture, features, ML workflow, API documentation, screenshots, and future improvements.

Include ethical and safety disclaimers explaining that the system is an educational decision-support tool, not a guaranteed-return system or substitute for a licensed financial advisor.

Final Goal

The final application should demonstrate a complete AI + Machine Learning + Explainable AI + Financial Analytics + Full-Stack Development workflow and should be polished enough to showcase as a major portfolio/GitHub project.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://ember-finance-ai.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/34994ccf-c1a8-46c4-aabe-475426048a84).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
